const express = require("express");
const path = require("path"); // Tambahkan ini
console.log("APP.JS DIJALANKAN");
const dbOperations = require("./crud");

const app = express();
const port = 3000;

app.use(express.json());

// --- ROUTE UNTUK HALAMAN WEB ---
app.get("/", (req, res) => {
  // Tambahkan 'public' di dalam path.join
  res.sendFile(path.join(__dirname, "public", "index.html"));
});
// --- ENDPOINT API (Disamakan dengan fetch di HTML) ---

// Ambil Data
app.get("/api/mahasiswa", (req, res) => {
  dbOperations.getAllMahasiswa((error, results) => {
    if (error) return res.status(500).send("Error fetching");
    res.json(results);
  });
});

// Tambah Data
app.post("/api/mahasiswa", (req, res) => {
  const data = req.body;
  dbOperations.createMahasiswa(data, (error) => {
    if (error) return res.status(500).send("Error creating");
    res.status(201).send("Mahasiswa created");
  });
});

// Update Data
app.put("/api/mahasiswa/:id", (req, res) => {
  const { id } = req.params;
  const { nama, nim, jurusan, email } = req.body;
  dbOperations.updateMahasiswa(id, nama, nim, jurusan, email, (error) => {
    if (error) return res.status(500).send("Error updating");
    res.send("Mahasiswa updated");
  });
});

// Hapus Data
app.delete("/api/mahasiswa/:id", (req, res) => {
  const { id } = req.params;
  dbOperations.deleteMahasiswa(id, (error) => {
    if (error) return res.status(500).send("Error deleting");
    res.send("Mahasiswa deleted");
  });
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
