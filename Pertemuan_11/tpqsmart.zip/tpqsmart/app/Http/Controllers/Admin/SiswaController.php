<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Siswa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class SiswaController extends Controller
{
    public function index()
    {
        $siswaList = Siswa::with('user')->get(); 
        return view('admin.data_pengguna', compact('siswaList'));
    }

    /**
     * Show detail siswa
     */
    public function show($id)
    {
        // Ambil data siswa dengan relasi user
        $siswa = Siswa::with('user')->findOrFail($id);
        
        // Debug - hapus setelah berhasil
        \Log::info('Detail Siswa:', [
            'id' => $siswa->id,
            'nama' => $siswa->nama_lengkap,
            'user_id' => $siswa->user_id
        ]);
    
        return view('admin.data_pengguna.siswa.detail_siswa', compact('siswa'));
    }

    public function store(Request $request)
    {
        Log::info('Siswa Store Request:', $request->all());

        // 1. Validasi Input
        $validated = $request->validate([
            'username' => 'required|unique:users,username|min:5',
            'password' => 'required|min:8',
            'idSiswa' => 'required|unique:siswas,nis',
            'nama' => 'required|string|max:255',
            'kelas' => 'required|string',
            'jenisKelamin' => 'required|in:Laki-laki,Perempuan',
            'tempat_lahir' => 'required|string|max:255',
            'tanggal_lahir' => 'required|date',
            'alamat' => 'required|string',
            'no_hp' => 'required|string|min:10',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ], [
            'username.required' => 'Username wajib diisi',
            'username.unique' => 'Username sudah digunakan',
            'username.min' => 'Username minimal 5 karakter',
            'password.required' => 'Password wajib diisi',
            'password.min' => 'Password minimal 8 karakter',
            'idSiswa.required' => 'ID Siswa wajib diisi',
            'idSiswa.unique' => 'ID Siswa sudah digunakan',
            'nama.required' => 'Nama lengkap wajib diisi',
            'kelas.required' => 'Kelas wajib dipilih',
            'jenisKelamin.required' => 'Jenis kelamin wajib dipilih',
            'tempat_lahir.required' => 'Tempat lahir wajib diisi',
            'tanggal_lahir.required' => 'Tanggal lahir wajib diisi',
            'tanggal_lahir.date' => 'Format tanggal lahir tidak valid',
            'alamat.required' => 'Alamat wajib diisi',
            'no_hp.required' => 'Nomor handphone orang tua wajib diisi',
            'no_hp.min' => 'Nomor handphone minimal 10 digit',
            'foto.image' => 'File harus berupa gambar',
            'foto.max' => 'Ukuran foto maksimal 2MB',
        ]);

        try {
            DB::beginTransaction();

            // 2. Handle foto upload
            $fotoPath = null;
            if ($request->hasFile('foto')) {
                $foto = $request->file('foto');
                $fotoName = time() . '_' . $validated['idSiswa'] . '.' . $foto->getClientOriginalExtension();
                // ✅ Simpan ke storage/app/public/photos/siswa
                $fotoPath = $foto->storeAs('photos/siswa', $fotoName, 'public');
            }

            // 3. Simpan ke tabel Users (untuk login)
            $user = User::create([
                'name'     => $validated['nama'],
                'username' => $validated['username'],
                'password' => Hash::make($validated['password']),
                'role'     => 'siswa',
            ]);

            // 4. Simpan ke tabel Siswas (biodata) - ✅ FOTO DISIMPAN DI SINI
            Siswa::create([
                'user_id'       => $user->id,
                'nis'           => $validated['idSiswa'],
                'nama_lengkap'  => $validated['nama'],
                'kelas'         => $validated['kelas'],
                'jenis_kelamin' => $validated['jenisKelamin'],
                'tempat_lahir'  => $validated['tempat_lahir'],
                'tanggal_lahir' => $validated['tanggal_lahir'],
                'alamat'        => $validated['alamat'],
                'no_hp'         => $validated['no_hp'],
                'foto'          => $fotoPath, // ✅ SIMPAN FOTO DI TABEL SISWA
            ]);

            DB::commit();

            Log::info('Siswa created successfully:', ['user_id' => $user->id]);

            return response()->json([
                'success' => true, 
                'message' => 'Data siswa berhasil ditambahkan!'
            ], 200);

        } catch (\Exception $e) {
            DB::rollback();
            
            Log::error('Error creating siswa:', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'success' => false, 
                'message' => 'Terjadi kesalahan: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Show the form for editing siswa
     */
    public function edit($id)
    {
        $siswa = Siswa::with('user')->findOrFail($id);
        return view('admin.data_pengguna.siswa.edit_siswa', compact('siswa'));
    }

    /**
     * Update siswa data
     */
    public function update(Request $request, $id)
    {
        Log::info('Siswa Update Request:', $request->all());

        $siswa = Siswa::with('user')->findOrFail($id);

        // Validasi Input
        $validated = $request->validate([
            'username' => 'required|min:5|unique:users,username,' . $siswa->user_id,
            'password' => 'nullable|min:8',
            'idSiswa' => 'required|unique:siswas,nis,' . $id,
            'nama' => 'required|string|max:255',
            'kelas' => 'required|string',
            'jenisKelamin' => 'required|in:Laki-laki,Perempuan',
            'tempat_lahir' => 'required|string|max:255',
            'tanggal_lahir' => 'required|date',
            'alamat' => 'required|string',
            'no_hp' => 'required|string|min:10',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        try {
            DB::beginTransaction();

            // Handle foto upload baru
            if ($request->hasFile('foto')) {
                // Hapus foto lama jika ada
                if ($siswa->foto && \Storage::disk('public')->exists($siswa->foto)) {
                    \Storage::disk('public')->delete($siswa->foto);
                }

                $foto = $request->file('foto');
                $fotoName = time() . '_' . $validated['idSiswa'] . '.' . $foto->getClientOriginalExtension();
                $validated['foto'] = $foto->storeAs('photos/siswa', $fotoName, 'public');
            }

            // Update User
            $userData = [
                'name' => $validated['nama'],
                'username' => $validated['username'],
            ];

            if ($request->filled('password')) {
                $userData['password'] = Hash::make($validated['password']);
            }

            $siswa->user->update($userData);

            // Update Siswa
            $siswa->update([
                'nis' => $validated['idSiswa'],
                'nama_lengkap' => $validated['nama'],
                'kelas' => $validated['kelas'],
                'jenis_kelamin' => $validated['jenisKelamin'],
                'tempat_lahir' => $validated['tempat_lahir'],
                'tanggal_lahir' => $validated['tanggal_lahir'],
                'alamat' => $validated['alamat'],
                'no_hp' => $validated['no_hp'],
                'foto' => $validated['foto'] ?? $siswa->foto,
            ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Data siswa berhasil diperbarui!'
            ], 200);

        } catch (\Exception $e) {
            DB::rollback();
            
            Log::error('Error updating siswa:', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete siswa
     */
    public function destroy($id)
    {
        try {
            $siswa = Siswa::with('user')->findOrFail($id);

            // Hapus foto jika ada
            if ($siswa->foto && \Storage::disk('public')->exists($siswa->foto)) {
                \Storage::disk('public')->delete($siswa->foto);
            }

            // Hapus user (cascade akan hapus siswa juga)
            $siswa->user->delete();

            return redirect()->route('admin.data_pengguna')
                           ->with('success', 'Data siswa berhasil dihapus!');

        } catch (\Exception $e) {
            Log::error('Error deleting siswa:', [
                'message' => $e->getMessage()
            ]);

            return redirect()->route('admin.data_pengguna')
                           ->with('error', 'Gagal menghapus data siswa!');
        }
    }
}