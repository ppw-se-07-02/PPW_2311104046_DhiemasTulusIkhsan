@extends('master')
@section('title','Data Produk')
@section('content')
Produk 1 : {{ $prod1; }}
<br>
Produk 2 : {{ $prod2; }}
<br>
Produk 2 : {{ $prod3; }}
@endsection